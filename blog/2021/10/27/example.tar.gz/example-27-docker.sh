#!/bin/bash
cd /mnt/Piranha21.10.0/bin
./run.sh
