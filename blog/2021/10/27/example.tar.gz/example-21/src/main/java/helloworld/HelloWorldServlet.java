package helloworld;

import cloud.piranha.embedded.EmbeddedPiranha;
import cloud.piranha.embedded.EmbeddedPiranhaBuilder;
import cloud.piranha.http.embedded.EmbeddedHttpServerProcessor;
import cloud.piranha.http.impl.DefaultHttpServer;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class HelloWorldServlet extends HttpServlet {
    
    public HelloWorldServlet() {
    }

    @Override
    protected void doGet(HttpServletRequest request, 
            HttpServletResponse response) throws IOException, ServletException {
        try (PrintWriter writer = response.getWriter()) {
            writer.println("Hello World");
            writer.flush();
        }
    }

    public static void main(String[] arguments) throws Exception {
        System.out.println("TIME1: " + System.currentTimeMillis());
        EmbeddedPiranha piranha = new EmbeddedPiranhaBuilder()
                .servlet("HelloWorld", HelloWorldServlet.class)
                .build();
        
        DefaultHttpServer server = new DefaultHttpServer(8080, 
                new EmbeddedHttpServerProcessor(piranha), false);
        
        server.start();
        System.out.println("TIME2: " + System.currentTimeMillis());
    }
}
