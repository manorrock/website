
module helloworld {

    exports helloworld;
    requires cloud.piranha.http.api;
    requires cloud.piranha.http.impl;
    requires cloud.piranha.http.webapp;
    requires cloud.piranha.http.nano;
    requires cloud.piranha.nano;
    requires jakarta.servlet;
}
