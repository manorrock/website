package example.example7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Example7Application {

    public static void main(String[] args) {
        SpringApplication.run(Example7Application.class, args);
    }
}
