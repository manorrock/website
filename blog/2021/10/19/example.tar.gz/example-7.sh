#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
java -jar example-7/target/example7.jar
