package example.example9;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloWorldController {
    
    public HelloWorldController() {
        System.out.println("TIME1: " + System.currentTimeMillis());
    }

    @RequestMapping(value = "/")
    public String helloWorld() {
        return "Hello World!";
    }
}
