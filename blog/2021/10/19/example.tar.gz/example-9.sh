#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
java -jar example-9/target/example9.jar
