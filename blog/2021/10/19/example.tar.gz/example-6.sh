#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
java -jar example-6/target/example6.jar
