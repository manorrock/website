package example.example8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Example8Application {

    public static void main(String[] args) {
        SpringApplication.run(Example8Application.class, args);
    }
}
