package example.example30;

import io.helidon.config.Config;
import io.helidon.webserver.Routing;
import io.helidon.webserver.WebServer;

public final class Main {

    public static void main(final String[] args) {
        System.out.println("TIME1: " + System.currentTimeMillis());

        Config config = Config.create().get("server");

        WebServer server = WebServer.create(
                Routing.builder()
                        .get("", (request,response) -> response.send("Hello World"))
                        .build(),
                config);

        server.start().thenRun(() -> {
            System.out.println("TIME2: " + System.currentTimeMillis());
        });
    }
}
