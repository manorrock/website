package example.example31;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.core.Application;

@ApplicationScoped
public class GreetApplication extends Application {
    
    public GreetApplication() {
        System.out.println("TIME1: " + System.currentTimeMillis());
    }
}
