package example.example31;

import javax.enterprise.context.RequestScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@RequestScoped
@Path("/helloWorld")
public class GreetResource {

    public GreetResource() {
        System.out.println("TIME2: " + System.currentTimeMillis());
    }

    @GET
    public String helloWorld() {
        return "Hello World!";
    }
}
