#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
java -jar example-30/target/example30.jar
