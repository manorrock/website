package example.example18;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "HelloWorldServlet", urlPatterns = {""})
public class HelloWorldServlet extends HttpServlet {
    
    public HelloWorldServlet() {
        System.out.println("TIME2: " + System.currentTimeMillis());
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        
        response.setContentType("text/plain");
        try ( PrintWriter out = response.getWriter()) {
            out.println("Hello World!");
        }
    }
}
