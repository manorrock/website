#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
jshell example-1.jshell
