#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
java -jar example-2/target/example2.jar
