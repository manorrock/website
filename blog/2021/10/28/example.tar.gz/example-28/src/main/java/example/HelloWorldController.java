package example;

import static io.micronaut.http.MediaType.TEXT_PLAIN;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Produces;

@Controller("/")
public class HelloWorldController {
    
    public HelloWorldController() {
        System.out.println("TIME2: " + System.currentTimeMillis());
    }

    @Get
    @Produces(TEXT_PLAIN)
    public String index() {
        return "Hello World";
    }
}
