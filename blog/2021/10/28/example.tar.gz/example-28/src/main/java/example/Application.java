package example;

import io.micronaut.runtime.Micronaut;

public class Application {

    public static void main(String[] args) {
        System.out.println("TIME1: " + System.currentTimeMillis());
        Micronaut.run(Application.class, args);
    }
}
