#!/bin/bash
set -m
echo 'TIME0:' `gdate +%s%3N`
java -jar example-37/target/example37-fat.jar