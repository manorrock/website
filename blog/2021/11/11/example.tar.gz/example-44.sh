#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
node example-44.js
