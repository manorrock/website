#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
./example-41/target/example41
