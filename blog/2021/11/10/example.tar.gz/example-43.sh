#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
docker run --rm -it -v $PWD:/mnt ruby ruby /mnt/example-42.rb
