#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
ruby example-42.rb
