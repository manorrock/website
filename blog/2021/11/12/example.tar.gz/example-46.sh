#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
python3 example-46.py
