#!/bin/sh

echo 'TIME0:' `gdate +%s%3N`
./example-48/example48
