package helloworld;

import io.inverno.core.annotation.Bean;
import io.inverno.core.v1.Application;
import io.inverno.mod.web.annotation.WebController;
import io.inverno.mod.web.annotation.WebRoute;

@Bean
@WebController
public class App {
    
    @WebRoute( path = "/" )
    public String hello() {
        System.out.println("TIME2: " + System.currentTimeMillis());
        return "Hello World";
    }

    public static void main(String[] args) {
        System.out.println("TIME1: " + System.currentTimeMillis());
        Application.run(new Helloworld.Builder());
    }
}
