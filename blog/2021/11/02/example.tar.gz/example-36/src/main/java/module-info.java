import io.inverno.core.annotation.Module;

@Module
        
module helloworld {
    requires io.inverno.mod.boot;
    requires io.inverno.mod.web;
}
