/*
 * Permission to use, copy, modify, and/or distribute this software for any 
 * purpose with or without fee is hereby granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR(S) DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
 * OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
package helloworld;

import com.manorrock.piranha.DefaultHttpServer;
import com.manorrock.piranha.DefaultWebApplication;
import com.manorrock.piranha.DefaultWebApplicationServer;
import com.manorrock.piranha.api.HttpServer;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * An example that demonstrates you can use a servlet as a function by using
 * Manorrock Piranha and GraalVM together.
 *
 * @author Manfred Riem (mriem@manorrock.org)
 */
public class HelloWorldFunction extends HttpServlet {

    /**
     * Stores the boolean to terminate.
     */
    private boolean done = false;
    
    /**
     * Process the request.
     *
     * @param request the request.
     * @param response the response.
     * @throws IOException when an I/O error occurs.
     * @throws ServletException when a Servlet error occurs.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        response.setContentType("text/plain");
        PrintWriter writer = response.getWriter();
        writer.println("Hello World");
        done = true;
    }
    
    /**
     * Are we done?
     * 
     * @return true if we are, false otherwise.
     */
    public boolean isDone() {
        return done;
    }

    /**
     * Main method.
     *
     * @param arguments the arguments.
     */
    public static void main(String[] arguments) {
        DefaultWebApplicationServer server = new DefaultWebApplicationServer();
        HttpServer httpServer = new DefaultHttpServer(8080, server);
        DefaultWebApplication webApp = new DefaultWebApplication();
        webApp.setContextPath("");
        HelloWorldFunction function = new HelloWorldFunction();
        webApp.addServlet("function", function);
        webApp.addServletMapping("function", "/*");
        server.addWebApplication(webApp);
        server.initialize();
        server.start();
        httpServer.start();
        while (true) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException ie) {

            }
            if (function.isDone()) {
                break;
            }
        }
        System.exit(0);
    }
}
