/*
 * Permission to use, copy, modify, and/or distribute this software for any 
 * purpose with or without fee is hereby granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR(S) DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
 * OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
package serverless;

import com.manorrock.piranha.DefaultWebApplication;
import com.manorrock.piranha.DefaultWebApplicationClassLoader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import javax.servlet.ServletException;

/**
 * The Wrapper can be used as a concept to wrap standard input and standard 
 * output handling for a WAR.
 *
 * @author Manfred Riem (mriem@manorrock.com)
 */
public class WarWrapper {

    /**
     * Process method.
     *
     * @param inputStream the (standard in) input stream.
     * @param outputStream the (standard out) output stream.
     */
    public void process(InputStream inputStream, PrintStream outputStream) {

        DefaultWebApplication webApp = new DefaultWebApplication();
        webApp.setClassLoader(new DefaultWebApplicationClassLoader(new File("./webapp")));
        webApp.addServlet("HelloWorld", "serverless.HelloWorldServlet");
        webApp.addServletMapping("HelloWorld", "/*");
        webApp.initialize();
        webApp.start();

        ByteBufferHttpServletRequest request = new ByteBufferHttpServletRequest();
        request.setWebApplication(webApp);
        request.setContextPath("");
        request.setServletPath("/helloWorld");

        ByteBufferHttpServletResponse response = new ByteBufferHttpServletResponse();
        ByteBufferServletOutputStream bufferedOutputStream = new ByteBufferServletOutputStream();
        response.setOutputStream(bufferedOutputStream);
        bufferedOutputStream.setResponse(response);

        try {
            webApp.service(request, response);
            response.flushBuffer();
            outputStream.write(bufferedOutputStream.getBytes());
            outputStream.flush();
        } catch (ServletException | IOException e) {
            e.printStackTrace(outputStream);
        }

        webApp.stop();
    }

    /**
     * Main method.
     *
     * @param arguments the arguments.
     */
    public static void main(String[] arguments) {
        WarWrapper wrapper = new WarWrapper();
        wrapper.process(System.in, System.out);
    }
}
