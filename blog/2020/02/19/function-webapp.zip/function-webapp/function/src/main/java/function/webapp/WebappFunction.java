/*
 * Copyright (c) 2002-2020 Manorrock.com. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 *   1. Redistributions of source code must retain the above copyright notice, 
 *      this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *   3. Neither the name of the copyright holder nor the names of its 
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package function.webapp;

import cloud.piranha.DefaultDirectoryResource;
import cloud.piranha.DefaultServlet;
import cloud.piranha.DefaultWebApplicationClassLoader;
import cloud.piranha.api.WebApplication;
import cloud.piranha.embedded.EmbeddedPiranha;
import cloud.piranha.embedded.EmbeddedRequest;
import cloud.piranha.embedded.EmbeddedRequestBuilder;
import cloud.piranha.embedded.EmbeddedResponse;
import cloud.piranha.embedded.EmbeddedResponseBuilder;
import cloud.piranha.servlet.webxml.WebXmlInitializer;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.BindingName;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import javax.servlet.ServletException;

/**
 * A function dispatching to a web application using Piranha Embedded.
 *
 * @author Manfred Riem (mriem@manorrock.com)
 */
public class WebappFunction {

    /**
     * Stores the single instance of Piranha Embedded.
     */
    private static EmbeddedPiranha EMBEDDED_PIRANHA;

    /**
     * Run the function.
     *
     * @param request the request.
     * @param path the path.
     * @param context the execution context.
     * @return the response.
     */
    @FunctionName("webapp")
    public HttpResponseMessage run(
            @HttpTrigger(
                    name = "request",
                    methods = {HttpMethod.GET, HttpMethod.POST},
                    route = "{path}",
                    authLevel = AuthorizationLevel.ANONYMOUS
            ) HttpRequestMessage<Optional<String>> request,
            @BindingName("path") String path,
            final ExecutionContext context) {

        /**
         * Build the Embedded request.
         */
        EmbeddedRequest embeddedRequest = new EmbeddedRequestBuilder()
                .method(request.getHttpMethod().name())
                .servletPath(path.equals("") ? "" : "/" + path)
                .build();

        /**
         * Build the Embedded response.
         */
        EmbeddedResponse embeddedResponse = new EmbeddedResponseBuilder()
                .build();

        /**
         * Build up the Piranha Embedded runtime and dispatch the request and
         * response to it and then capture the response.
         */
        String body = null;

        try {
            if (EMBEDDED_PIRANHA == null) {
                EMBEDDED_PIRANHA = new EmbeddedPiranha();
                WebApplication webApplication = EMBEDDED_PIRANHA.getWebApplication();
                webApplication.setClassLoader(new DefaultWebApplicationClassLoader(new File("webapp")));
                webApplication.addResource(new DefaultDirectoryResource("webapp"));
                webApplication.addInitializer(WebXmlInitializer.class.getName());
                webApplication.addServlet("DefaultServlet", DefaultServlet.class.getName());
                webApplication.addServletMapping("DefaultServlet", "/*");
                webApplication.initialize();
                webApplication.start();
            }
            EMBEDDED_PIRANHA.service(embeddedRequest, embeddedResponse);
        } catch (IOException | ServletException e) {
            body = e.getMessage();
        }

        if (body == null) {
            body = embeddedResponse.getResponseAsString();
        }

        /**
         * Return the function response.
         */
        return request.createResponseBuilder(HttpStatus.OK).
                header("Content-Type", "text/html").
                body(body).
                build();
    }
}
