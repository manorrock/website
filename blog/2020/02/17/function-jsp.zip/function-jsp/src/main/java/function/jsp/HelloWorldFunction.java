/*
 * Copyright (c) 2002-2020 Manorrock.com. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 *   1. Redistributions of source code must retain the above copyright notice, 
 *      this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *   3. Neither the name of the copyright holder nor the names of its 
 *      contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package function.jsp;

import cloud.piranha.nano.NanoPiranha;
import cloud.piranha.nano.NanoPiranhaBuilder;
import cloud.piranha.nano.NanoRequest;
import cloud.piranha.nano.NanoRequestBuilder;
import cloud.piranha.nano.NanoResponse;
import cloud.piranha.nano.NanoResponseBuilder;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import javax.servlet.ServletException;
import org.apache.jasper.servlet.JspServlet;

/**
 * A simple function dispatching to a 'Hello World' JSP page using Piranha Nano.
 *
 * @author Manfred Riem (mriem@manorrock.com)
 */
public class HelloWorldFunction {

    /**
     * Run the function.
     *
     * @param request the request.
     * @param context the execution context.
     * @return the response.
     */
    @FunctionName("/helloworld")
    public HttpResponseMessage run(
            @HttpTrigger(
                    name = "request",
                    methods = {HttpMethod.GET},
                    authLevel = AuthorizationLevel.FUNCTION
            ) HttpRequestMessage<Optional<String>> request,
            final ExecutionContext context) {

        /**
         * Build the Nano request.
         */
        NanoRequest nanoRequest = new NanoRequestBuilder()
                .method("GET")
                .servletPath("/helloworld.jsp")
                .build();

        /**
         * Build the Nano response.
         */
        ByteArrayOutputStream nanoOutputStream = new ByteArrayOutputStream();
        NanoResponse nanoResponse = new NanoResponseBuilder()
                .outputStream(nanoOutputStream)
                .build();

        /**
         * Build up the Piranha Nano runtime and dispatch the request and
         * response to it and then capture the response.
         */
        String body = null;

        File[] libFiles = new File("lib").listFiles();
        StringBuilder classpath = new StringBuilder();
        if (libFiles != null) {
            for (int i = 0; i < libFiles.length; i++) {
                classpath.append(libFiles[i].getAbsolutePath());
                if (i + 1 != libFiles.length) {
                    classpath.append(File.pathSeparatorChar);
                }
            }
        }
        try {
            NanoPiranha piranha = new NanoPiranhaBuilder()
                    .directoryResource("webapp")
                    .servlet("JSP Servlet", new JspServlet())
                    .servletInitParam("JSP Servlet", "classpath", classpath.toString())
                    .servletInitParam("JSP Servlet", "compilerSourceVM", "1.8")
                    .servletInitParam("JSP Servlet", "compilerTargetVM", "1.8")
                    .servletInitParam("JSP Servlet", "fork", "false")
                    .build();
            piranha.service(nanoRequest, nanoResponse);
        } catch (IOException | ServletException e) {
            body = e.getMessage();
        }

        if (body == null) {
            body = nanoOutputStream.toString();
        }

        /**
         * Return the function response.
         */
        return request.createResponseBuilder(HttpStatus.OK).
                header("Content-Type", "text/html").
                body(body).
                build();
    }
}
