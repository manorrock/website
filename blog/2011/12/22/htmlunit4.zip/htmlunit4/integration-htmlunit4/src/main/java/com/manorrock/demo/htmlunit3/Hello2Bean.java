/*
 * Copyright (c) 2002-2011 Manorrock.com. All Rights Reserved.
 */
package com.manorrock.demo.htmlunit3;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 * @author Manfred Riem (mriem@manorrock.com)
 */
@ManagedBean(name = "hello2Bean")
@RequestScoped
public class Hello2Bean {

    /**
     * Say hello :)
     */
    public String getHello() {
        return "Hello";
    }
}
