# Azure Management SDK + JShell

This project demonstrates how to use JShell, which is available in Java 9 or later
to administer your Azure subscription.

To start using it, first build the project with Maven using:

```
  mvn clean package
```

Then in a shell at the top of the project do (on a Linux/macOS):

```
  CLASSPATH=./target/jars/* jshell
```

Now your JShell environment is ready to use the scripts available in the
```src/main/jshell``` directory.

Note to do the following steps we are using a service principal to connect to
Azure so you will need to set it up before you continue (see
https://docs.microsoft.com/en-us/cli/azure/create-an-azure-service-principal-azure-cli)

Do the following:

```
   /open src/main/jshell/authenticate_with_service_principal.jshell
```

This will load the snippet that allows you to authenticate with a service principal.

The next step is to use a Java Properties object to set up your authentication,
note you will have to fill in the jshell.properties with the relevant properties.

Now enter:

```
  Properties properties = new Properties();
  properties.load(new FileInputStream("jshell.properties"))
  var azure = authenticateWithServicePrincipalWithProperties(properties)
```

And voila you can now interact with the Azure Java Management SDK in JShell!
